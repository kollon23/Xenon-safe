#define NOMINMAX
#include <windows.h>
#include <gdiplus.h>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <mmsystem.h>

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment(lib, "gdiplus.lib")

using namespace Gdiplus;

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

int w = GetSystemMetrics(SM_CXSCREEN);
int h = GetSystemMetrics(SM_CYSCREEN);

HFONT hCustomFont = NULL;
LPCWSTR currentWarningText = L"";
bool warningResult = false;

typedef struct _RGBRAMP {
    WORD Red[256];
    WORD Green[256];
    WORD Blue[256];
} RGBRAMP;

typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE b;
        BYTE g;
        BYTE r;
        BYTE Reserved;
    };
} _RGBQUAD, *PRGBQUAD;

void ResetGammaRamp(HDC hdc) {
    RGBRAMP ramp;
    for (int i = 0; i < 256; i++) {
        WORD value = (WORD)(i * 257);
        ramp.Red[i] = value;
        ramp.Green[i] = value;
        ramp.Blue[i] = value;
    }
    SetDeviceGammaRamp(hdc, &ramp);
}

void ClearScreen() {
    RedrawWindow(NULL, NULL, NULL, RDW_INVALIDATE | RDW_ALLCHILDREN | RDW_UPDATENOW | RDW_ERASE);
}

// ==========================================
// --- КАСТОМНОЕ ОКНО ПРЕДУПРЕЖДЕНИЯ ---
// ==========================================
LRESULT CALLBACK CustomWarningProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_CREATE: {
        hCustomFont = CreateFontW(
            20, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Noto Serif"
        );

        HWND hStatic = CreateWindowExW(
            0, L"STATIC", currentWarningText,
            WS_VISIBLE | WS_CHILD | SS_CENTER,
            20, 20, 480, 140, hwnd, NULL, NULL, NULL
        );
        if (hCustomFont) SendMessage(hStatic, WM_SETFONT, (WPARAM)hCustomFont, TRUE);

        HWND hBtnNo = CreateWindowExW(
            0, L"BUTTON", L"No / いいえ",
            WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
            40, 180, 200, 40, hwnd, (HMENU)101, NULL, NULL
        );
        if (hCustomFont) SendMessage(hBtnNo, WM_SETFONT, (WPARAM)hCustomFont, TRUE);

        HWND hBtnYes = CreateWindowExW(
            0, L"BUTTON", L"Yes / はい",
            WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
            260, 180, 200, 40, hwnd, (HMENU)102, NULL, NULL
        );
        if (hCustomFont) SendMessage(hBtnYes, WM_SETFONT, (WPARAM)hCustomFont, TRUE);
        break;
    }
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        
        RECT rc;
        GetClientRect(hwnd, &rc);

        TRIVERTEX vert[2];
        GRADIENT_RECT gRect;

        vert[0].x = rc.left;
        vert[0].y = rc.top;
        vert[0].Red = 0x00 << 8;   
        vert[0].Green = 0xFF << 8; 
        vert[0].Blue = 0x7F << 8;  
        vert[0].Alpha = 0x0000;

        vert[1].x = rc.right;
        vert[1].y = rc.bottom;
        vert[1].Red = 0x00 << 8;   
        vert[1].Green = 0x00 << 8; 
        vert[1].Blue = 0xFF << 8;  
        vert[1].Alpha = 0x0000;

        gRect.UpperLeft = 0;
        gRect.LowerRight = 1;

        GradientFill(hdc, vert, 2, &gRect, 1, GRADIENT_FILL_RECT_V);

        EndPaint(hwnd, &ps);
        break;
    }
    case WM_CTLCOLORSTATIC: {
        HDC hdcStatic = (HDC)wParam;
        SetBkMode(hdcStatic, TRANSPARENT);
        SetTextColor(hdcStatic, RGB(0, 0, 0));
        return (LRESULT)GetStockObject(NULL_BRUSH);
    }
    case WM_COMMAND: {
        int id = LOWORD(wParam);
        if (id == 102) {
            warningResult = true;  
            DestroyWindow(hwnd);
        } else if (id == 101) {
            warningResult = false; 
            DestroyWindow(hwnd);
        }
        break;
    }
    case WM_CLOSE:
        warningResult = false;
        DestroyWindow(hwnd);
        return 0;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

bool ShowCustomWarning(LPCWSTR text) {
    currentWarningText = text;
    warningResult = false;

    WNDCLASSW wc = { 0 };
    wc.lpfnWndProc = CustomWarningProc;
    wc.hInstance = GetModuleHandle(NULL);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.lpszClassName = L"XenonWarningClass";
    RegisterClassW(&wc);

    HWND hwnd = CreateWindowExW(
        0, L"XenonWarningClass", L"Xenon",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU,
        CW_USEDEFAULT, CW_USEDEFAULT, 540, 280,
        NULL, NULL, GetModuleHandle(NULL), NULL
    );

    if (!hwnd) return false;

    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    if (hCustomFont) {
        DeleteObject(hCustomFont);
        hCustomFont = NULL;
    }
    UnregisterClassW(L"XenonWarningClass", GetModuleHandle(NULL));

    return warningResult;
}

// ==========================================
// --- ОБЩИЙ ГЕНЕРАТОР ЗВУКА ---
// ==========================================
DWORD WINAPI SoundThreadN(LPVOID lpParam) {
    int stageNum = (int)(INT_PTR)lpParam;

    int sampleRate = (stageNum == 1 || stageNum == 20) ? 11025 : (stageNum == 14) ? 32000 : 8000;
    int sampleLimit = sampleRate * 30;

    HWAVEOUT hWaveOut;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (WORD)sampleRate, (DWORD)sampleRate, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    int totalSamples = sampleRate * 30;
    char* buffer = new char[totalSamples];

    for (int t = 0; t < totalSamples; t++) {
        unsigned int val = 0;

        switch (stageNum) {
            case 1:
                val = t < 330750 ? t * (3 + (1 ^ t >> 10 & 5)) * (5 + (3 & t >> 14)) >> (t >> 8 & 3) : 0;
                break;
            case 2:
                val = t < sampleLimit ? (t * ((t >> 8 | t << 13) & 15) + t & 129 + (t >> 5 | t << 2)) : 0;
                break;
            case 3:
                val = t < sampleLimit ? 9 * t & t >> 4 | 5 * t & t >> 7 | (3 * t & t >> 10) - 1 : 0;
                break;
            case 4:
                val = t < 240000 ? ((-t & 4095) * (255 & t * (t & t >> 13)) >> 12) + (127 & t * (234 & t >> 8 & t >> 3) >> (3 & t >> 14)) : 0;
                break;
            case 5:
                val = t < sampleLimit ? (9 * t & t >> 4 | 5 * t & t >> 7 | 3 * t & t >> 10) - 1 : 0;
                break;
            case 6:
                val = t < sampleLimit ? (t >> 2) * (t >> 5) | t >> 5 : 0;
                break;
            case 7:
                val = t < sampleLimit ? (t * (42 & t >> 7)) : 0;
                break;
            case 8:
                val = t < sampleLimit ? (t * (3 + (1 ^ 5 & t >> 10)) * (5 + (3 & t >> 14)) >> (3 & t >> 8)) : 0;
                break;
            case 9:
                val = t < sampleLimit ? t * (t ^ t + (t >> 15 | 1) ^ (t - 1280 ^ t) >> 10) * t : 0;
                break;
            case 10:
                val = t < sampleLimit ? 10 * (t & 5 * t | t >> 6 | (t & 32768 ? -6 * t / 7 : (t & 65536 ? -9 * t & 100 : -9 * (t & 100)) / 11)) : 0;
                break;
            case 11:
                val = t < sampleLimit ? t * (t ^ t + (t >> 15 | 1) ^ (t - 1280 ^ t) >> 10) : 0;
                break;
            case 12:
                val = t < sampleLimit ? (t * 3 & t >> 6) % 76 : 0;
                break;
            case 13:
                val = t < 240000 ? (2 * t * ((t >> 10 | t >> 8) & 15)) : 0;
                break;
            case 14:
                val = t < 960000 ? t * ((t - 2296 & t) >> 11) : 0;
                break;
            case 15:
                val = t < 240000 ? t * (((t >> 9) ^ ((t >> 9) - 1) ^ 1) % 13) : 0;
                break;
            case 16:
                val = t < 240000 ? t >> (t & 7) | t << (t & 42) | t << 5 : 0;
                break;
            case 17:
                val = t < 240000 ? t * (t & 16384 ? 7 : 5) * (4 - (1 & t >> 8)) >> (3 & t >> 8) | t >> (t & 4096 ? 3 : 4) : 0;
                break;
            case 18:
                val = t < 240000 ? (-t * (0xCA98CA98 >> (-t >> 9 & 30) & 15) | -t >> 8) : 0;
                break;
            case 19:
                val = t < 240000 ? t * (t & 16384 ? 7 : 5) * (3 + (3 & t >> 14)) >> (3 & t >> 9) : 0;
                break;
            case 20:
                val = t < 330750 ? t * (1 + (t >> 10) * (43 + 2 * (t >> 15 - (t >> 16) % 13) % 8) % 8) * (1 + (t >> 14) % 4) : 0;
                break;
            case 21:
                val = t < 240000 ? (t * ((t / 2 >> 10 | t % 16 * t >> 8) & 8 * t >> 12 & 18) | -t / (16) + 64) & (t * ((t / 2 >> 10 | t % 16 * t >> 8) & 8 * t >> 12 & 18) | -(t >> 4) + 64) : 0;
                break;
            case 22:
                val = t < 240000 ? t * (322376503 >> (t >> 13 & 27) & 127) | t >> 4 | t << 5 : 0;
                break;
            case 23:
                val = t < 240000 ? (t * t * (1 + (t >> 8 & t >> 9)) & 128) : 0;
                break;
            case 24:
                val = t < 240000 ? (t >> 2) * (t & (t & 32768 ? 16 : 24) | t >> (t >> 8 & 24)) | t >> 3 : 0;
                break;
            case 25:
                val = t < 240000 ? t * (t & t >> 5) : 0;
                break;
            case 26:
                val = t < 240000 ? t*((t&4096?t%65536<59392?7:t&7:16)+(1&t>>14))>>(3&-t>>(t&2048?2:10))|t>>(t&16384?t&4096?10:3:2) : 0;
                break;
        }

        buffer[t] = (char)val;
    }

    WAVEHDR hdr = { buffer, (DWORD)totalSamples, 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &hdr, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &hdr, sizeof(WAVEHDR));

    Sleep(30000);

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &hdr, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
    delete[] buffer;
    return 0;
}

// ==========================================
// --- HSL -> RGB КОНВЕРТЕР ---
// ==========================================
Color HSLToRGB(float h, float s, float l)
{
    float c = (1.0f - fabsf(2.0f * l - 1.0f)) * s;
    float hp = h / 60.0f;
    float x = c * (1.0f - fabsf(fmodf(hp, 2.0f) - 1.0f));
    float r1 = 0, g1 = 0, b1 = 0;
 
    if (hp >= 0 && hp < 1)      { r1 = c; g1 = x; b1 = 0; }
    else if (hp >= 1 && hp < 2) { r1 = x; g1 = c; b1 = 0; }
    else if (hp >= 2 && hp < 3) { r1 = 0; g1 = c; b1 = x; }
    else if (hp >= 3 && hp < 4) { r1 = 0; g1 = x; b1 = c; }
    else if (hp >= 4 && hp < 5) { r1 = x; g1 = 0; b1 = c; }
    else                        { r1 = c; g1 = 0; b1 = x; }
 
    float m = l - c / 2.0f;
    BYTE r = (BYTE)std::clamp((int)lroundf((r1 + m) * 255.0f), 0, 255);
    BYTE g = (BYTE)std::clamp((int)lroundf((g1 + m) * 255.0f), 0, 255);
    BYTE b = (BYTE)std::clamp((int)lroundf((b1 + m) * 255.0f), 0, 255);
 
    return Color(255, r, g, b);
}

// ==========================================
// --- ЭТАПЫ 1 - 25 ---
// ==========================================
void Stage1(HDC hdc) {
    ShowCursor(TRUE);
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)1, 0, NULL);
    DWORD startTime = GetTickCount();
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP hbmMem = CreateCompatibleBitmap(hdc, w, h);
    SelectObject(hdcMem, hbmMem);
    HICON icons[] = { LoadIcon(NULL, IDI_ERROR), LoadIcon(NULL, IDI_WARNING), LoadIcon(NULL, IDI_QUESTION), LoadIcon(NULL, IDI_INFORMATION), LoadIcon(NULL, IDI_APPLICATION) };
    double waveAngle = 0;
    while (GetTickCount() - startTime < 30000) {
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < 3; i++) {
            int rx = rand() % w, ry = rand() % h;
            int size = 16 + (rand() % 81);
            DrawIconEx(hdcMem, rx, ry, icons[rand() % 5], size, size, 0, NULL, DI_NORMAL);
        }
        for (int y = 0; y < h; y += 1) {
            int offsetX = (int)(sin(y * 0.15 + waveAngle) * 50.0);
            BitBlt(hdc, offsetX, y, w, 1, hdcMem, 0, y, SRCCOPY);
        }
        waveAngle += 10;
        Sleep(10);
    }
    DeleteObject(hbmMem); DeleteDC(hdcMem);
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

int redrawCounter_s2 = 0;

void Stage2(HDC hdc) {
    ShowCursor(TRUE);
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)2, 0, NULL);
    DWORD startTime = GetTickCount();
    redrawCounter_s2 = 0;

    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP hbmMem = CreateCompatibleBitmap(hdc, w, h);
    HBITMAP hOldBmp = (HBITMAP)SelectObject(hdcMem, hbmMem);

    BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

    while (GetTickCount() - startTime < 30000) {
        BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);

        const float amplitude = 25.0f;

        for (float t = 0.0f; t < 10.0f; t += 0.1f)
        {
            float sinValue = sinf(t);

            redrawCounter_s2 += 10;
            int y = redrawCounter_s2;
            int x = (int)(sinValue * amplitude);

            if (redrawCounter_s2 >= h)
            {
                redrawCounter_s2 = 0;
            }

            BitBlt(hdc, x, y, w, 10, hdcMem, 0, y, SRCCOPY);
        }

        MSG msg;
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    SelectObject(hdcMem, hOldBmp);
    DeleteObject(hbmMem);
    DeleteDC(hdcMem);

    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage3(HDC hdc) {
    ShowCursor(TRUE);
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)3, 0, NULL);
    DWORD startTime = GetTickCount();
    int lineCount = 0, colorIdx = 0;
    COLORREF rainbow[] = { RGB(255,0,0), RGB(255,127,0), RGB(255,255,0), RGB(0,255,0), RGB(0,255,255), RGB(0,0,255), RGB(139,0,211), RGB(255,20,147) };
    HICON icons[4] = { LoadIcon(NULL, IDI_ERROR), LoadIcon(NULL, IDI_WARNING), LoadIcon(NULL, IDI_QUESTION), LoadIcon(NULL, IDI_INFORMATION) };
    while (GetTickCount() - startTime < 30000) {
        BitBlt(hdc, 0, (rand() % 31) - 15, w, h, hdc, 0, 0, SRCCOPY);
        HPEN hPen = CreatePen(PS_SOLID, 5, rainbow[colorIdx]);
        SelectObject(hdc, hPen);
        POINT p[4] = { {0, 0}, {rand() % w, rand() % h}, {rand() % w, rand() % h}, {rand() % w, rand() % h} };
        PolyBezier(hdc, p, 4);
        if (++lineCount >= 50) { lineCount = 0; colorIdx = (colorIdx + 1) % 8; }
        DeleteObject(hPen);
        POINT cur; GetCursorPos(&cur);
        DrawIcon(hdc, cur.x + rand() % 60 - 30, cur.y + rand() % 60 - 30, icons[rand() % 4]);
        Sleep(10);
    }
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage4(HDC hdc) {
    ShowCursor(TRUE);
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)4, 0, NULL);
    DWORD startTime = GetTickCount();
    DWORD lastInvert = GetTickCount();
    while (GetTickCount() - startTime < 30000) {
        if (GetTickCount() - lastInvert >= 1000) {
            PatBlt(hdc, 0, 0, w, h, PATINVERT);
            lastInvert = GetTickCount();
        }
        int x = rand() % w, y = rand() % h;
        int width = 50 + (rand() % 150), height = 50 + (rand() % 150);
        HBRUSH brush = CreateSolidBrush(RGB(rand() % 256, rand() % 256, rand() % 256));
        HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, brush);
        Pie(hdc, x, y, x + width, y + height, x + width + (rand() % 50), y + height / 2 + (rand() % 40 - 20), x + width + (rand() % 50), y + height / 2 - (rand() % 40 - 20));
        SelectObject(hdc, oldBrush); DeleteObject(brush);
        HFONT hFont = CreateFontW(20 + (rand() % 40), 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Arial");
        HFONT oldFont = (HFONT)SelectObject(hdc, hFont);
        SetBkMode(hdc, TRANSPARENT); SetTextColor(hdc, RGB(rand() % 256, rand() % 256, rand() % 256));
        TextOutW(hdc, rand() % (w - 200), rand() % (h - 50), L"Xenon", 5);
        SelectObject(hdc, oldFont); DeleteObject(hFont);
        Sleep(1);
    }
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage5(HDC hdc) {
    ShowCursor(TRUE);
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)5, 0, NULL);
    DWORD startTime = GetTickCount();

    _RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);

    while (GetTickCount() - startTime < 30000) {
        HDC desk = GetDC(NULL); 
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data); 
        SelectObject(hdcdc, hbm);
        
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY); 
        GetBitmapBits(hbm, w * h * 4, data);
        
        for (int i = 0; w * h > i; i++) {
            data[i].rgb = (data[i].rgb * 2) % (RGB(0, 0, 255));
        }
        
        SetBitmapBits(hbm, w * h * 4, data); 
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        
        DeleteObject(hbm); 
        DeleteDC(hdcdc); 
        ReleaseDC(NULL, desk);

        Sleep(15);
    }

    VirtualFree(data, 0, MEM_RELEASE);
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

DWORD WINAPI TextSpamThread(LPVOID lpParam) {
    HFONT hFont = CreateFontW(24, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Consolas");
    while (true) {
        HDC desk = GetDC(0);
        HGDIOBJ oldFont = SelectObject(desk, hFont);
        SetTextColor(desk, RGB(255, rand() % 100, rand() % 100));
        SetBkMode(desk, TRANSPARENT);
        LPCWSTR text = L"Xenon destroying ur PC lol";
        TextOutW(desk, rand() % (w - 350), rand() % (h - 50), text, wcslen(text));
        SelectObject(desk, oldFont); ReleaseDC(0, desk);
        Sleep(200);
    }
    return 0;
}

void Stage6(HDC hdc) {
    ShowCursor(TRUE);
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)6, 0, NULL);
    HANDLE hText = CreateThread(NULL, 0, TextSpamThread, NULL, 0, NULL);
    DWORD startTime = GetTickCount(); double angle = 0;
    while (GetTickCount() - startTime < 30000) {
        for (float i = 0; i < w; i += 0.99f) {
            int a = (int)(sin(angle) * 12.0);
            BitBlt(hdc, i, 0, 1, h, hdc, i, a, SRCCOPY);
            angle += M_PI / 30;
        }
        Sleep(5);
    }
    if (hText) { TerminateThread(hText, 0); CloseHandle(hText); }
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage7(HDC hdc) {
    ShowCursor(TRUE);
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)7, 0, NULL);
    DWORD startTime = GetTickCount();
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
    BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO); bmi.bmiHeader.biBitCount = 32; bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = sw; bmi.bmiHeader.biHeight = sh; bmi.bmiHeader.biCompression = BI_RGB;
    HDC hdcMem = CreateCompatibleDC(hdc); HBITMAP hbmTemp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, NULL); SelectObject(hdcMem, hbmTemp);
    while (GetTickCount() - startTime < 30000) {
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < sw * sh; i++) rgbScreen[i].rgb -= 666;
        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
        Sleep(15);
    }
    DeleteObject(hbmTemp); DeleteDC(hdcMem);
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage8(HDC hdc) {
    ShowCursor(TRUE);
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)8, 0, NULL);
    DWORD startTime = GetTickCount();
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
    HDC hdcMem = CreateCompatibleDC(hdc); HBITMAP hbmMem = CreateCompatibleBitmap(hdc, sw, sh); SelectObject(hdcMem, hbmMem);
    int radius = 40, ballX = sw / 2, ballY = sh / 2, dx = 8, dy = 6;
    double hueAngle = 0.0, stretchY = 1.0;
    while (GetTickCount() - startTime < 30000) {
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
        stretchY += 0.003; if (stretchY > 3.0) stretchY = 1.0;
        int newH = (int)(sh * stretchY), offsetY = (newH - sh) / 2;
        SetStretchBltMode(hdc, COLORONCOLOR);
        StretchBlt(hdc, 0, -offsetY, sw, newH, hdcMem, 0, 0, sw, sh, SRCCOPY);
        ballX += dx; ballY += dy;
        if (ballX - radius <= 0 || ballX + radius >= sw) { dx = -dx; hueAngle += 60.0; if (hueAngle >= 360.0) hueAngle -= 360.0; }
        if (ballY - radius <= 0 || ballY + radius >= sh) { dy = -dy; hueAngle += 60.0; if (hueAngle >= 360.0) hueAngle -= 360.0; }
        int hi = (int)(hueAngle / 60.0) % 6;
        double f = hueAngle / 60.0 - (int)(hueAngle / 60.0);
        int q = (int)(255 * (1 - f)), t = (int)(255 * f);
        int R, G, B;
        switch (hi) {
            case 0: R = 255; G = t;   B = 0;   break;
            case 1: R = q;   G = 255; B = 0;   break;
            case 2: R = 0;   G = 255; B = t;   break;
            case 3: R = 0;   G = q;   B = 255; break;
            case 4: R = t;   G = 0;   B = 255; break;
            case 5: R = 255; G = 0;   B = q;   break;
            default: R = 255; G = 0; B = 0; break;
        }
        HBRUSH ballBrush = CreateSolidBrush(RGB(R, G, B));
        HPEN ballPen = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
        HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, ballBrush);
        HPEN oldPen = (HPEN)SelectObject(hdc, ballPen);
        Ellipse(hdc, ballX - radius, ballY - radius, ballX + radius, ballY + radius);
        SelectObject(hdc, oldBrush); SelectObject(hdc, oldPen);
        DeleteObject(ballBrush); DeleteObject(ballPen);
        Sleep(5);
    }
    DeleteObject(hbmMem); DeleteDC(hdcMem);
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

int red_s9 = 0, green_s9 = 0, blue_s9 = 0;
bool ifblue_s9 = false;

COLORREF Hue_s9(int length) {
    if (red_s9 != length) {
        red_s9++;
        if (ifblue_s9 == true) {
            return RGB(red_s9, 0, length);
        } else {
            return RGB(red_s9, 0, 0);
        }
    } else {
        if (green_s9 != length) {
            green_s9++;
            return RGB(length, green_s9, 0);
        } else {
            if (blue_s9 != length) {
                blue_s9++;
                return RGB(0, length, blue_s9);
            } else {
                red_s9 = 0; green_s9 = 0; blue_s9 = 0;
                ifblue_s9 = true;
            }
        }
    }
    return RGB(0, 0, 0);
}

void Stage9(HDC hdc) {
    ShowCursor(TRUE);
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)9, 0, NULL);
    DWORD startTime = GetTickCount();
    float colorAngle = 0.0f;
    SetStretchBltMode(hdc, COLORONCOLOR);

    while (GetTickCount() - startTime < 30000) {
        StretchBlt(hdc, -20, 0, w, h + 20, hdc, 0, 0, w, h, SRCCOPY);
        colorAngle += 0.05f;
        int r = (int)((sinf(colorAngle) + 1.0f) * 127);
        int g = (int)((sinf(colorAngle + 2.094f) + 1.0f) * 127);
        int b = (int)((sinf(colorAngle + 4.188f) + 1.0f) * 127);
        HBRUSH hBrush = CreateSolidBrush(RGB(r, g, b));
        HBRUSH hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
        PatBlt(hdc, 0, 0, w, h, PATPAINT);
        SelectObject(hdc, hOldBrush); DeleteObject(hBrush);

        HPEN hPen = CreatePen(PS_SOLID, 5, Hue_s9(239));
        HPEN hOldPen = (HPEN)SelectObject(hdc, hPen);
        POINT p[4] = { 
            {w, 0}, 
            {rand() % w, rand() % h}, 
            {rand() % w, rand() % h}, 
            {rand() % w, rand() % h} 
        };
        PolyBezier(hdc, p, 4);
        SelectObject(hdc, hOldPen); DeleteObject(hPen);

        Sleep(30);
    }
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage10(HDC hdc) {
    ShowCursor(TRUE);
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)10, 0, NULL);
    DWORD startTime = GetTickCount();
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
    BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO); bmi.bmiHeader.biBitCount = 32; bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = sw; bmi.bmiHeader.biHeight = sh; bmi.bmiHeader.biCompression = BI_RGB;
    HDC hdcMem = CreateCompatibleDC(hdc); HBITMAP hbmTemp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, NULL); SelectObject(hdcMem, hbmTemp);
    HDC hdcTunnel = CreateCompatibleDC(hdc); HBITMAP hbmTunnel = CreateCompatibleBitmap(hdc, sw, sh); SelectObject(hdcTunnel, hbmTunnel);
    double scale = 1.0;
    while (GetTickCount() - startTime < 30000) {
        scale *= 0.95; if (scale < 0.05) scale = 1.0;
        int newW = (int)(sw * scale), newH = (int)(sh * scale);
        int offsetX = (sw - newW) / 2, offsetY = (sh - newH) / 2;
        BitBlt(hdcTunnel, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
        SetStretchBltMode(hdc, COLORONCOLOR);
        StretchBlt(hdc, offsetX, offsetY, newW, newH, hdcTunnel, 0, 0, sw, sh, SRCCOPY);
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
        for (int i = 0; i < sw * sh; i++) rgbScreen[i].rgb -= 666;
        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
        Sleep(15);
    }
    DeleteObject(hbmTemp); DeleteDC(hdcMem); DeleteObject(hbmTunnel); DeleteDC(hdcTunnel);
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage11(HDC hdc) {
    ShowCursor(TRUE);
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)11, 0, NULL);
    DWORD startTime = GetTickCount();
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
    int lineCount = 0, colorIdx = 0;
    COLORREF rainbow[] = { RGB(255,0,0), RGB(255,127,0), RGB(255,255,0), RGB(0,255,0), RGB(0,255,255), RGB(0,0,255), RGB(139,0,211), RGB(255,20,147) };
    HDC hdcMem = CreateCompatibleDC(hdc); HBITMAP hbmMem = CreateCompatibleBitmap(hdc, sw, sh); SelectObject(hdcMem, hbmMem);
    HDC hdcTemp = CreateCompatibleDC(hdc); HBITMAP hbmTemp = CreateCompatibleBitmap(hdc, sw, sh); SelectObject(hdcTemp, hbmTemp);
    double currentScale = 0.95, currentAngle = M_PI / 18; int frameCount = 0;
    while (GetTickCount() - startTime < 30000) {
        if (frameCount % 10 == 0) {
            BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
            BitBlt(hdcTemp, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
            int newW = (int)(sw * currentScale), newH = (int)(sh * currentScale);
            int offsetX = (sw - newW) / 2, offsetY = (sh - newH) / 2;
            StretchBlt(hdcTemp, offsetX, offsetY, newW, newH, hdcMem, 0, 0, sw, sh, SRCCOPY);
            int cx = sw / 2, cy = sh / 2; POINT pts[3];
            pts[0].x = cx + (int)(-cx * cos(currentAngle) + cy * sin(currentAngle));
            pts[0].y = cy + (int)(-cx * sin(currentAngle) - cy * cos(currentAngle));
            pts[1].x = cx + (int)(cx * cos(currentAngle) + cy * sin(currentAngle));
            pts[1].y = cy + (int)(cx * sin(currentAngle) - cy * cos(currentAngle));
            pts[2].x = cx + (int)(-cx * cos(currentAngle) - cy * sin(currentAngle));
            pts[2].y = cy + (int)(-cx * sin(currentAngle) + cy * cos(currentAngle));
            PlgBlt(hdc, pts, hdcTemp, 0, 0, sw, sh, NULL, 0, 0);
            currentScale *= 0.95; currentAngle += M_PI / 18;
            if (currentScale < 0.05) { currentScale = 0.95; currentAngle = M_PI / 18; }
        }
        HPEN hPen = CreatePen(PS_SOLID, 5, rainbow[colorIdx]); SelectObject(hdc, hPen);
        POINT p[4] = { {sw / 2, sh / 2}, {rand() % sw, rand() % sh}, {rand() % sw, rand() % sh}, {rand() % sw, rand() % sh} };
        PolyBezier(hdc, p, 4);
        if (++lineCount >= 50) { lineCount = 0; colorIdx = (colorIdx + 1) % 8; }
        DeleteObject(hPen); frameCount++; Sleep(1);
    }
    DeleteObject(hbmMem); DeleteDC(hdcMem); DeleteObject(hbmTemp); DeleteDC(hdcTemp);
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage12(HDC hdc) {
    ShowCursor(TRUE);
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)12, 0, NULL);
    DWORD startTime = GetTickCount();
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
    HDC hdcMem = CreateCompatibleDC(hdc); HBITMAP hbmMem = CreateCompatibleBitmap(hdc, sw, sh); SelectObject(hdcMem, hbmMem);
    HFONT hFont = CreateFontW(18, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Consolas");
    LPCWSTR text = L"Xenon.exe";
    while (GetTickCount() - startTime < 30000) {
        BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
        for (int y = 0; y < sh; y += 2) {
            int shiftY = (int)(sin((y + GetTickCount() * 0.1) * 0.05) * 30.0) + (y / 10);
            int srcY = y + shiftY; while (srcY >= sh) srcY -= sh; while (srcY < 0) srcY += sh;
            BitBlt(hdc, 0, y, sw, 2, hdcMem, 0, srcY, SRCCOPY);
        }
        for (int i = 0; i < 3; i++) {
            int rx = rand() % (sw - 150), ry = rand() % (sh - 50);
            HBRUSH blackBrush = CreateSolidBrush(RGB(0, 0, 0));
            RECT textRect = { rx - 5, ry - 2, rx + 100, ry + 25 };
            FillRect(hdc, &textRect, blackBrush); DeleteObject(blackBrush);
            COLORREF textColor = RGB(rand() % 256, rand() % 256, rand() % 256);
            SetBkMode(hdc, TRANSPARENT); SetTextColor(hdc, textColor);
            SelectObject(hdc, hFont); TextOutW(hdc, rx, ry, text, wcslen(text));
        }
        Sleep(15);
    }
    DeleteObject(hbmMem); DeleteDC(hdcMem); DeleteObject(hFont);
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage13(HDC hdc) {
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)13, 0, NULL);
    DWORD startTime = GetTickCount();

    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP hbmMem = CreateCompatibleBitmap(hdc, w, h);
    HBITMAP hOldBmp = (HBITMAP)SelectObject(hdcMem, hbmMem);

    double waveAngle = 0;

    while (GetTickCount() - startTime < 30000) {
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

        for (int y = 0; y < h; y += 1) {
            int offsetX = (int)(sin(y * 0.15 + waveAngle) * 150.0);
            BitBlt(hdc, offsetX, y, w, 1, hdcMem, 0, y, SRCCOPY);
        }

        waveAngle += 10;

        MSG msg;
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        Sleep(15);
    }

    SelectObject(hdcMem, hOldBmp);
    DeleteObject(hbmMem);
    DeleteDC(hdcMem);

    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage14(HDC hdc) {
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)14, 0, NULL);
    DWORD startTime = GetTickCount();
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
    while (GetTickCount() - startTime < 30000) {
        for (int i = 0; i < 100; i++) {
            int x = rand() % sw;
            int y = rand() % sh;
            BitBlt(hdc, x, y, 50, 50, hdc, x + (rand() % 21 - 10), y + (rand() % 21 - 10), SRCCOPY);
        }
        Sleep(1);
    }
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage15(HDC hdc) {
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)15, 0, NULL);
    DWORD startTime = GetTickCount();
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
    HICON hError = LoadIcon(NULL, IDI_ERROR);
    while (GetTickCount() - startTime < 30000) {
        for (int i = 0; i < 50; i++) DrawIcon(hdc, rand() % sw, rand() % sh, hError);
        Sleep(1);
    }
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage16(HDC hdc) {
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)16, 0, NULL);
    DWORD startTime = GetTickCount();
    _RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    while (GetTickCount() - startTime < 30000) {
        HDC desk = GetDC(NULL); HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data); SelectObject(hdcdc, hbm);
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY); GetBitmapBits(hbm, w * h * 4, data);
        for (int i = 0; w * h > i; i++) data[i].rgb = (data[i].rgb * 2) % (RGB(0, 255, 255));
        SetBitmapBits(hbm, w * h * 4, data); BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        DeleteObject(hbm); DeleteDC(hdcdc); DeleteDC(desk);
        Sleep(15);
    }
    VirtualFree(data, 0, MEM_RELEASE);
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage17(HDC hdc) {
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)17, 0, NULL);
    DWORD startTime = GetTickCount();

    int radius = 50, ballX = w / 2, ballY = h / 2, dx = 25, dy = 20;
    double hueAngle = 0.0;
    _RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);

    while (GetTickCount() - startTime < 30000) {
        HDC desk = GetDC(NULL); 
        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data); 
        SelectObject(hdcdc, hbm);
        
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY); 
        GetBitmapBits(hbm, w * h * 4, data);
        
        for (int i = 0; w * h > i; i++) {
            data[i].rgb = (data[i].rgb * 2) % (RGB(0, 0, 255));
        }
        
        SetBitmapBits(hbm, w * h * 4, data); 
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        
        DeleteObject(hbm); 
        DeleteDC(hdcdc); 
        DeleteDC(desk);

        ballX += dx; ballY += dy;
        if (ballX - radius <= 0 || ballX + radius >= w) { dx = -dx; hueAngle += 60.0; if (hueAngle >= 360.0) hueAngle -= 360.0; }
        if (ballY - radius <= 0 || ballY + radius >= h) { dy = -dy; hueAngle += 60.0; if (hueAngle >= 360.0) hueAngle -= 360.0; }
        int hi = (int)(hueAngle / 60.0) % 6;
        double f = hueAngle / 60.0 - (int)(hueAngle / 60.0);
        int q = (int)(255 * (1 - f)), t = (int)(255 * f);
        int R, G, B;
        switch (hi) {
            case 0: R = 255; G = t;   B = 0;   break;
            case 1: R = q;   G = 255; B = 0;   break;
            case 2: R = 0;   G = 255; B = t;   break;
            case 3: R = 0;   G = q;   B = 255; break;
            case 4: R = t;   G = 0;   B = 255; break;
            case 5: R = 255; G = 0;   B = q;   break;
            default: R = 255; G = 0; B = 0; break;
        }
        HBRUSH ballBrush = CreateSolidBrush(RGB(R, G, B));
        HPEN ballPen = CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
        HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, ballBrush);
        HPEN oldPen = (HPEN)SelectObject(hdc, ballPen);
        Ellipse(hdc, ballX - radius, ballY - radius, ballX + radius, ballY + radius);
        SelectObject(hdc, oldBrush); SelectObject(hdc, oldPen);
        DeleteObject(ballBrush); DeleteObject(ballPen);

        Sleep(25);
    }

    VirtualFree(data, 0, MEM_RELEASE);
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage18(HDC hdc) {
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)18, 0, NULL);
    DWORD startTime = GetTickCount();
    HICON hErr = LoadIcon(0, IDI_ERROR), hWarn = LoadIcon(0, IDI_WARNING), hApp = LoadIcon(0, IDI_APPLICATION);
    while (GetTickCount() - startTime < 30000) {
        StretchBlt(hdc, 10, 10, w - 20, h - 20, hdc, 0, 0, w, h, SRCINVERT);
        StretchBlt(hdc, -10, -10, w + 20, h + 20, hdc, 0, 0, w, h, SRCINVERT);
        for (int i = 0; i < 30; i++) {
            DrawIcon(hdc, rand() % w, rand() % h, hErr);
            DrawIcon(hdc, rand() % w, rand() % h, hWarn);
            DrawIcon(hdc, rand() % w, rand() % h, hApp);
        }
        Sleep(1);
    }
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage19(HDC hdc) {
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)19, 0, NULL);
    DWORD startTime = GetTickCount();

    double angle = 0;
    _RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);

    while (GetTickCount() - startTime < 30000) {
        for (float i = 0; i < w + h; i += 0.99f) {
            int a = (int)(sin(angle) * 20);
            HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
            HGDIOBJ oldBrush = SelectObject(hdc, brush);
            BitBlt(hdc, 0, (int)i, w, 1, hdc, a, (int)i, 0x1900ac010e);
            BitBlt(hdc, (int)i, 0, 1, h, hdc, (int)i, a, 0x1900ac010e);
            angle += M_PI / 40;
            SelectObject(hdc, oldBrush);
            DeleteObject(brush);
        }

        HDC hdcdc = CreateCompatibleDC(hdc);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
        HGDIOBJ oldBmp = SelectObject(hdcdc, hbm);

        BitBlt(hdcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
        GetBitmapBits(hbm, w * h * 4, data);

        for (int i = 0; w * h > i; i++) {
            data[i].rgb = (data[i].rgb * 2) % (RGB(0, 255, 255));
        }

        SetBitmapBits(hbm, w * h * 4, data);
        BitBlt(hdc, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);

        SelectObject(hdcdc, oldBmp);
        DeleteObject(hbm);
        DeleteDC(hdcdc);

        Sleep(1);
    }

    VirtualFree(data, 0, MEM_RELEASE);
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

DWORD WINAPI FastMasherThread(LPVOID lpParam) {
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
    while (true) {
        HDC hdc = GetDC(HWND_DESKTOP);
        BitBlt(hdc, rand() % 10 - 5, rand() % 10 - 5, rand() % sw, rand() % sh, hdc, rand() % 10 - 5, rand() % 10 - 5, SRCCOPY);
        ReleaseDC(0, hdc);
    }
    return 0;
}

void Stage20(HDC hdc) {
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)20, 0, NULL);
    HANDLE hMasher1 = CreateThread(NULL, 0, FastMasherThread, NULL, 0, NULL);
    HANDLE hMasher2 = CreateThread(NULL, 0, FastMasherThread, NULL, 0, NULL);

    Sleep(30000);

    if (hMasher1) { TerminateThread(hMasher1, 0); CloseHandle(hMasher1); }
    if (hMasher2) { TerminateThread(hMasher2, 0); CloseHandle(hMasher2); }
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage21(HDC hdc) {
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)21, 0, NULL);
    DWORD startTime = GetTickCount();

    HDC hdcMem = CreateCompatibleDC(hdc);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);

    while (GetTickCount() - startTime < 30000) {
        HDC hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
        for (int i = 0; i < w * h; i++) {
            rgbScreen[i].rgb = (rgbScreen[i].rgb * 2) % (RGB(255, 255, 255));
        }
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, -30, 0, SRCCOPY);
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, w - 30, 0, SRCCOPY);
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, -30, SRCCOPY);
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, h - 30, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        Sleep(1);
    }

    DeleteObject(hbmTemp);
    DeleteDC(hdcMem);
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage22(HDC hdc) {
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)22, 0, NULL);
    DWORD startTime = GetTickCount();
    SetStretchBltMode(hdc, COLORONCOLOR);

    while (GetTickCount() - startTime < 30000) {
        StretchBlt(hdc, -10, -10, w + 20, h + 20, hdc, 0, 0, w, h, SRCCOPY);
        Sleep(1);
    }

    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage23(HDC hdc) {
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)23, 0, NULL);
    DWORD startTime = GetTickCount();

    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP hbmMem = CreateCompatibleBitmap(hdc, w, h);
    SelectObject(hdcMem, hbmMem);

    double angle = 0;

    while (GetTickCount() - startTime < 30000) {
        BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

        for (int y = 0; y < h; y += 2) {
            int a = (int)(sin(angle) * 40.0) + (y / 5);
            int srcY = y + a;
            while (srcY >= h) srcY -= h;
            while (srcY < 0) srcY += h;
            BitBlt(hdc, 0, y, w, 2, hdcMem, 0, srcY, SRCCOPY);
        }

        angle += M_PI / 20;
        Sleep(1);
    }

    DeleteObject(hbmMem);
    DeleteDC(hdcMem);

    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage24(HDC hdc) {
    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)24, 0, NULL);
    DWORD startTime = GetTickCount();

    _RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP hbmMem = CreateCompatibleBitmap(hdc, w, h);
    SelectObject(hdcMem, hbmMem);

    while (GetTickCount() - startTime < 30000) {
        HDC desk = GetDC(NULL); 

        BitBlt(desk, rand() % 5, rand() % 5, rand() % w, rand() % h, desk, rand() % 5, rand() % 5, SRCCOPY);

        int cx = rand() % w;
        int cy = rand() % h;
        int size = 200 + (rand() % 300);
        HRGN hrgn = CreateEllipticRgn(cx, cy, cx + size, cy + size);
        SelectClipRgn(desk, hrgn);
        BitBlt(desk, cx, cy, size, size, desk, cx, cy, NOTSRCCOPY);
        SelectClipRgn(desk, NULL);
        DeleteObject(hrgn);

        BitBlt(hdcMem, 0, 0, w, h, desk, 0, 0, SRCCOPY);
        for (int y = 0; y < h; y += 4) {
            int shift = (rand() % 9) - 4;
            BitBlt(desk, 0, y, w, 2, hdcMem, 0, y + shift, SRCCOPY);
        }

        HDC hdcdc = CreateCompatibleDC(desk);
        HBITMAP hbm = CreateBitmap(w, h, 1, 32, data); 
        SelectObject(hdcdc, hbm);
        
        BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY); 
        GetBitmapBits(hbm, w * h * 4, data);
        
        for (int i = 0; w * h > i; i++) {
            data[i].rgb = (data[i].rgb * 2) % (RGB(0, 0, 255));
        }
        
        SetBitmapBits(hbm, w * h * 4, data); 
        BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
        
        DeleteObject(hbm); 
        DeleteDC(hdcdc); 
        ReleaseDC(NULL, desk);

        Sleep(10);
    }

    DeleteObject(hbmMem);
    DeleteDC(hdcMem);
    VirtualFree(data, 0, MEM_RELEASE);
    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
}

void Stage25(HDC hdc) {
    ShowCursor(TRUE);

    GdiplusStartupInput gdiplusStartupInput;
    ULONG_PTR gdiplusToken;
    GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)25, 0, NULL);
    DWORD startTime = GetTickCount();
    DWORD lastClearTime = GetTickCount();
    int redrawCounter_s25 = 0;

    int sw = w, sh = h;
    
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP hbmMem = CreateCompatibleBitmap(hdc, sw, sh);
    HBITMAP hOldBmp = (HBITMAP)SelectObject(hdcMem, hbmMem);
    BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);

    HDC hdcBg = CreateCompatibleDC(hdc);
    HBITMAP hbmBg = CreateCompatibleBitmap(hdc, sw, sh);
    HBITMAP hOldBgBmp = (HBITMAP)SelectObject(hdcBg, hbmBg);
    BitBlt(hdcBg, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);

    int ballPosX = 100, ballPosY = 100;
    int ballWidth = 90, ballHeight = 90; 
    int moveStepX = 18, moveStepY = 15;
    
    int redrawCounter = 0; 
    int codcod = 0;

    while (GetTickCount() - startTime < 30000) {
        if (GetTickCount() - lastClearTime >= 1000) {
            BitBlt(hdcMem, 0, 0, sw, sh, hdcBg, 0, 0, SRCCOPY);
            lastClearTime = GetTickCount();
        }

        redrawCounter++;
        codcod += 2;

        {
            Graphics gMem(hdcMem);
            gMem.SetSmoothingMode(SmoothingModeAntiAlias);

            Color fillColor    = HSLToRGB((float)(redrawCounter % 360), 1.0f, 0.5f);
            Color outlineColor = HSLToRGB((float)(codcod % 360), 1.0f, 0.5f);

            SolidBrush brush(fillColor);
            Pen pen(outlineColor, 2.0f);

            gMem.FillEllipse(&brush, ballPosX, ballPosY, ballWidth, ballHeight);
            gMem.DrawEllipse(&pen, ballPosX, ballPosY, ballWidth, ballHeight);
        }

        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);

        const float amplitude = 25.0f;

        for (float t = 0.0f; t < 10.0f; t += 0.1f)
        {
            float sinValue = sinf(t);

            redrawCounter_s25 += 10;
            int y = redrawCounter_s25;
            int x = (int)(sinValue * amplitude);

            if (redrawCounter_s25 >= sh)
            {
                redrawCounter_s25 = 0;
            }

            BitBlt(hdc, x, y, sw, 10, hdcMem, 0, y, SRCCOPY);
        }

        ballPosX += moveStepX;
        if (ballPosX < 0 || ballPosX + ballWidth > sw)
            moveStepX = -moveStepX;

        ballPosY += moveStepY;
        if (ballPosY < 0 || ballPosY + ballHeight > sh)
            moveStepY = -moveStepY;

        MSG msg;
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        Sleep(10);
    }

    SelectObject(hdcMem, hOldBmp);
    DeleteObject(hbmMem);
    DeleteDC(hdcMem);

    SelectObject(hdcBg, hOldBgBmp);
    DeleteObject(hbmBg);
    DeleteDC(hdcBg);

    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }

    GdiplusShutdown(gdiplusToken);
}

// ==========================================
// --- ФИНАЛЬНЫЙ 26 ЭТАП ---
// ==========================================
void Stage26(HDC hdc) {
    ShowCursor(TRUE);

    GdiplusStartupInput gdiplusStartupInput;
    ULONG_PTR gdiplusToken;
    GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

    HANDLE hSound = CreateThread(NULL, 0, SoundThreadN, (LPVOID)(INT_PTR)26, 0, NULL);
    DWORD startTime = GetTickCount();
    DWORD lastClearTime = GetTickCount();

    int sw = w, sh = h;
    
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP hbmMem = CreateCompatibleBitmap(hdc, sw, sh);
    HBITMAP hOldBmp = (HBITMAP)SelectObject(hdcMem, hbmMem);
    BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);

    HDC hdcBg = CreateCompatibleDC(hdc);
    HBITMAP hbmBg = CreateCompatibleBitmap(hdc, sw, sh);
    HBITMAP hOldBgBmp = (HBITMAP)SelectObject(hdcBg, hbmBg);
    BitBlt(hdcBg, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);

    _RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (sw * sh + sw) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);

    int ballPosX = 100, ballPosY = 100;
    int ballWidth = 90, ballHeight = 90; 
    int moveStepX = 18, moveStepY = 15;
    
    int redrawCounter = 0; 
    int codcod = 0;

    HFONT hFont = CreateFontW(28, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_OUTLINE_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, VARIABLE_PITCH, L"Consolas");

    while (GetTickCount() - startTime < 30000) {
        if (GetTickCount() - lastClearTime >= 1000) {
            BitBlt(hdcMem, 0, 0, sw, sh, hdcBg, 0, 0, SRCCOPY);
            lastClearTime = GetTickCount();
        }

        redrawCounter++;
        codcod += 2;

        {
            Graphics gMem(hdcMem);
            gMem.SetSmoothingMode(SmoothingModeAntiAlias);

            Color fillColor    = HSLToRGB((float)(redrawCounter % 360), 1.0f, 0.5f);
            Color outlineColor = HSLToRGB((float)(codcod % 360), 1.0f, 0.5f);

            SolidBrush brush(fillColor);
            Pen pen(outlineColor, 2.0f);

            gMem.FillEllipse(&brush, ballPosX, ballPosY, ballWidth, ballHeight);
            gMem.DrawEllipse(&pen, ballPosX, ballPosY, ballWidth, ballHeight);
        }

        BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);

        {
            HDC desk = GetDC(NULL); 
            HDC hdcdc = CreateCompatibleDC(desk);
            HBITMAP hbm = CreateBitmap(sw, sh, 1, 32, data); 
            SelectObject(hdcdc, hbm);
            
            BitBlt(hdcdc, 0, 0, sw, sh, desk, 0, 0, SRCCOPY); 
            GetBitmapBits(hbm, sw * sh * 4, data);
            
            for (int i = 0; sw * sh > i; i++) {
                data[i].rgb = (data[i].rgb * 2) % (RGB(0, 255, 255));
            }
            
            SetBitmapBits(hbm, sw * sh * 4, data); 
            BitBlt(desk, 0, 0, sw, sh, hdcdc, 0, 0, SRCCOPY);
            
            DeleteObject(hbm); 
            DeleteDC(hdcdc); 
            ReleaseDC(NULL, desk);
        }

        SetBkMode(hdc, TRANSPARENT);
        SetTextColor(hdc, RGB(rand() % 256, rand() % 256, rand() % 256));
        SelectObject(hdc, hFont);
        TextOutW(hdc, rand() % (sw - 200), rand() % (sh - 50), L"Xenon.exe", 9);

        ballPosX += moveStepX;
        if (ballPosX < 0 || ballPosX + ballWidth > sw)
            moveStepX = -moveStepX;

        ballPosY += moveStepY;
        if (ballPosY < 0 || ballPosY + ballHeight > sh)
            moveStepY = -moveStepY;

        MSG msg;
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        Sleep(15);
    }

    VirtualFree(data, 0, MEM_RELEASE);
    DeleteObject(hFont);
    SelectObject(hdcMem, hOldBmp);
    DeleteObject(hbmMem);
    DeleteDC(hdcMem);

    SelectObject(hdcBg, hOldBgBmp);
    DeleteObject(hbmBg);
    DeleteDC(hdcBg);

    if (hSound) { WaitForSingleObject(hSound, 30000); CloseHandle(hSound); }
    GdiplusShutdown(gdiplusToken);

    MessageBoxW(NULL, L"Thank you for downloading my program!", L"Xenon", MB_OK | MB_ICONINFORMATION);
}

// ==========================================
// --- ТОЧКА ВХОДА ---
// ==========================================
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
    if (!ShowCustomWarning(L"このプログラムは危険なマルウェアではありません！\nThis program is not a dangerous malware!\nGDIエフェクトのみです！ (GDI only!)\n\nてんかん注意！ (Epilepsy warning!)\n実行しますか？ (Run?)")) 
        return 0;

    if (!ShowCustomWarning(L"本当に実行しますか？\n\nAre you sure?")) 
        return 0;

    HDC hdc = CreateDCW(L"DISPLAY", NULL, NULL, NULL);

    Stage1(hdc);  ClearScreen(); Sleep(500);
    Stage2(hdc);  ClearScreen(); ResetGammaRamp(hdc); Sleep(500);
    Stage3(hdc);  ClearScreen(); Sleep(500);
    Stage4(hdc);  ClearScreen(); ResetGammaRamp(hdc); Sleep(500);
    Stage5(hdc);  ClearScreen(); ResetGammaRamp(hdc); Sleep(500);
    Stage6(hdc);  ClearScreen(); Sleep(500);
    Stage7(hdc);  ClearScreen(); ResetGammaRamp(hdc); Sleep(500);
    Stage8(hdc);  ClearScreen(); Sleep(500);
    Stage9(hdc);  ClearScreen(); Sleep(500);
    Stage10(hdc); ClearScreen(); ResetGammaRamp(hdc); Sleep(500);
    Stage11(hdc); ClearScreen(); Sleep(500);
    Stage12(hdc); ClearScreen(); Sleep(500);
    Stage13(hdc); ClearScreen(); Sleep(500);
    Stage14(hdc); ClearScreen(); Sleep(500);
    Stage15(hdc); ClearScreen(); Sleep(500);
    Stage16(hdc); ClearScreen(); Sleep(500);
    Stage17(hdc); ClearScreen(); Sleep(500);
    Stage18(hdc); ClearScreen(); Sleep(500);
    Stage19(hdc); ClearScreen(); Sleep(500);
    Stage20(hdc); ClearScreen(); Sleep(500);
    Stage21(hdc); ClearScreen(); Sleep(500);
    Stage22(hdc); ClearScreen(); Sleep(500);
    Stage23(hdc); ClearScreen(); Sleep(500);
    Stage24(hdc); ClearScreen(); Sleep(500);
    Stage25(hdc); ClearScreen(); Sleep(500);
    Stage26(hdc);

    DeleteDC(hdc);
    return 0;
}